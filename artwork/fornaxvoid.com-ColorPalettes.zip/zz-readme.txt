##################################
##################################
###                            ###
###  FORNAXVOID.COM RESOURCES  ###
###                            ###
##################################
###                            ###
###   VINTAGE COLOR PALETTES   ###
###                            ###
##################################
##################################


I arranged vintage color palettes
for the use with modern computers.

Sources were mainly the genius articles on wikipedia:
[1] http://en.wikipedia.org/wiki/List_of_8-bit_computer_hardware_palettes
[2] http://en.wikipedia.org/wiki/List_of_video_game_console_palettes
[3] http://en.wikipedia.org/wiki/List_of_monochrome_and_RGB_palettes

There you can also find technical details on how
the palettes could be used, for example how many
colors could be used at a time. 

To simplify the use of the palettes in modern environments,
I added transparency, if enough space (palette <256 colors) was available.

2015 Fornax Void
www.fornaxvoid.com
fornaxvoid.tumblr.com